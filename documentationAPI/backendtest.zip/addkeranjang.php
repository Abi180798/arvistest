<?php
    include_once("config.php");
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
    $data = file_get_contents("php://input");
    if($data==null){
        echo "Data tidak boleh kosong";
    }else{
        $dataArray = json_decode("$data",true);
        $id_produk = $dataArray["id_produk"];
        $id_kategori = $dataArray["id_kategori"];
        $id_user = $dataArray["id_user"];
        $jml = $dataArray["jml"];
        if($id_user != ""){
            $sql = "insert into keranjang values (0,$id_produk,$id_kategori,$id_user,$jml)";
            $result = mysqli_query($mysqli,$sql);
                $value = array(
                "id_produk"=>$id_produk,
                "id_kategori"=>$id_kategori,
                "id_user"=>$id_user,
                "jml"=>$jml
            );
                if($result){
                $output->data = $value;
                $output->status = 200;
                $output->msg = "Berhasil";
                echo json_encode($output);
            }else{
                $output->data = [];
                $output->status = 400;
                $output->msg = "Gagal";
                
                echo json_encode($output);
                
            }
        }else{
            $output->data = [];
            $output->status = 400;
            if($kategori==""){
                $output->msg = "Data tidak boleh kosong";
                echo json_encode($output);
            }
        }
    }
?>