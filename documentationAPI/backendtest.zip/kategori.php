<?php
    include_once("config.php");
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
        
            $sql = "select * from kategori";
            $result = mysqli_query($mysqli,$sql);
            $hasil = array();
                while($row=mysqli_fetch_assoc($result)){
                    array_push($hasil,$row);
                }
            if($hasil>0){
                $output->data = $hasil;
                $output->status = 200;
                $output->msg = "Berhasil";
                echo json_encode($output);
            }else{
                $output->data = [];
                $output->status = 400;
                $output->msg = "Gagal";
                
                echo json_encode($output);
            }
?>