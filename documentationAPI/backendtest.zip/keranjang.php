<?php
    include_once("config.php");
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
    $data = file_get_contents("php://input");
    if($data==null){
        echo "Data tidak boleh kosong";
    }else{
        $dataArray = json_decode("$data",true);
        $user = $dataArray["user"];
        if($user != ""){
            $sql = "select k.id as id_keranjang ,k.*, p.* from keranjang k join produk p on k.id_produk=p.id where id_user='".$user."'";
            $result = mysqli_query($mysqli,$sql);
                $hasil = array();
                while($row=mysqli_fetch_assoc($result)){
                    array_push($hasil,$row);
                }            
                if($hasil>0){
                $output->data = $hasil;
                $output->status = 200;
                $output->msg = "Berhasil";
                echo json_encode($output);
            }else{
                $output->data = [];
                $output->status = 400;
                $output->msg = "Gagal";
                
                echo json_encode($output);
                
            }
        }else{
            $output->data = [];
            $output->status = 400;
            if($user==""){
                $output->msg = "User tidak boleh kosong";
                echo json_encode($output);
            }
        }
    }
?>