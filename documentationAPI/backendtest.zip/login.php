<?php
    include_once("config.php");
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
    $data = file_get_contents("php://input");
    if($data==null){
        echo "Data tidak boleh kosong";
    }else{
        $dataArray = json_decode("$data",true);
        $email = $dataArray["email"];
        $password = $dataArray["password"];
        if($email !="" && $password != ""){
            $sql = "select id, name, email from users where email='".$email."' and password='".$password."'";
            $result = mysqli_query($mysqli,$sql);
            $res = mysqli_fetch_assoc($result);
            if($res>0){
                $output->data = $res;
                $output->status = 200;
                $output->msg = "Berhasil";
                echo json_encode($output);
            }else{
                $output->data = "";
                $output->status = 400;
                $output->msg = "Gagal";
                
                echo json_encode($output);
                
            }
        }else{
            $output->data = "";
            $output->status = 400;
            if($email==""){
                $output->msg = "Email tidak boleh kosong";
                echo json_encode($output);
            }
            else if($password==""){
                $output->msg = "Password tidak boleh kosong";
                echo json_encode($output);
            }
        }
    }
?>