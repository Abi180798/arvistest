<?php
    include_once("config.php");
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
    $data = file_get_contents("php://input");
    if($data==null){
        echo "Data tidak boleh kosong";
    }else{
        $dataArray = json_decode("$data",true);
        $id_keranjang = $dataArray["id_keranjang"];
        if($id_keranjang != ""){
            $sql = "delete from keranjang where id=$id_keranjang";
            $result = mysqli_query($mysqli,$sql);
                if($result>0){
                $output->status = 200;
                $output->msg = "Berhasil";
                echo json_encode($output);
            }else{
                $output->data = [];
                $output->status = 400;
                $output->msg = "Gagal";
                
                echo json_encode($output);
                
            }
        }else{
            $output->data = [];
            $output->status = 400;
            if($id_keranjang==""){
                $output->msg = "id_keranjang tidak boleh kosong";
                echo json_encode($output);
            }
        }
    }
?>